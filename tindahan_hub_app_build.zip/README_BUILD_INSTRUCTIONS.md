# Tindahan HUB — App Build Package (.APK / iOS)

This zip package contains the complete source code, PWA manifest, service worker offline cache, and app icon for **Tindahan HUB**.

## Included Files
- `index.html` — Full single-file mobile web application (POS cashier, 11 business presets, category editor, bulk promos, daily sales dashboard, digital receipt sharing).
- `manifest.json` — Web App Manifest for mobile installation and metadata.
- `sw.js` — Service Worker for offline operation without internet.
- `icon.png` — 512x512 app icon.

---

## How to Build .APK (Android) & iOS Apps

### Option 1: WebIntoApp (Easiest Cloud APK Generator)
1. Go to [WebIntoApp.com](https://www.webintoapp.com).
2. Click **"Make App"** and select **"Upload HTML Files"**.
3. Upload this `tindahan_hub_app_build.zip` file.
4. Enter App Name: **Tindahan HUB** and upload `icon.png` as the app icon.
5. Click **"Generate APK"** to download your ready-to-install Android `.apk` file!

### Option 2: PWABuilder (For Google Play Store & iOS App Store)
1. Host `index.html`, `manifest.json`, `sw.js`, and `icon.png` on any free web host (e.g., GitHub Pages, Netlify, Vercel).
2. Enter your live website URL into [PWABuilder.com](https://www.pwabuilder.com).
3. Click **"Build My PWA"** and download the Android `.apk` / `.aab` package and iOS package.

### Option 3: Capacitor / Cordova (For Local Building in Android Studio)
1. Install Node.js and run:
   ```bash
   npm init -y
   npm install @capacitor/core @capacitor/cli @capacitor/android
   npx cap init "Tindahan HUB" "com.tindahanhub.app" --web-dir .
   npx cap add android
   npx cap open android
   ```
2. Build your `.apk` directly inside Android Studio.
